(function(t,j,n,h,s,e){t.hj=t.hj||function(){(t.hj.q=t.hj.q||[]).push(arguments)},t._hjSettings={hjid:1939682,hjsv:6},s=j.getElementsByTagName("head")[0],e=j.createElement("script"),e.defer=1,e.src=n+t._hjSettings.hjid+h+t._hjSettings.hjsv,s.appendChild(e)})(window,document,"https://static.hotjar.com/c/hotjar-",".js?sv=");

//# sourceMappingURL=hotjar.js.map