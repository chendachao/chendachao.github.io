self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "url": "./images/wechat-qr-code.86871ab10a9b22e9d837df84125dcd9e.jpg"
  },
  {
    "revision": "fce730f9756db4df478b",
    "url": "10.e03f7ade882a31b9acac.bundle.js"
  },
  {
    "revision": "06f77899710767b51281",
    "url": "2.33b2df0bd0277190233f.bundle.js"
  },
  {
    "revision": "0d57d2af5a65e396ac3d61eab39b863c",
    "url": "2.33b2df0bd0277190233f.bundle.js.LICENSE"
  },
  {
    "revision": "0eaf1d2235664843185d",
    "url": "3.3d8a2978c7891aa7c899.css"
  },
  {
    "revision": "2d7d3ae957e8afca53d7",
    "url": "7.0b988d2aa67525a513c3.css"
  },
  {
    "revision": "09cb083c07ea70d6bc78",
    "url": "8.4311987f138404cc1e6b.bundle.js"
  },
  {
    "revision": "ad7460b57f5468fe822d",
    "url": "9.ec89830db98d44440525.bundle.js"
  },
  {
    "revision": "0eaf1d2235664843185d",
    "url": "app.57d5880375cd984ecc68.bundle.js"
  },
  {
    "revision": "2351817742ecc337ea75f189d6e3a821",
    "url": "favicon.ico"
  },
  {
    "revision": "9266b3964806bded6e811d24167ab728",
    "url": "images/icons/icon-128x128.png"
  },
  {
    "revision": "b7fc5f254b8bc9d77492bde443e745a9",
    "url": "images/icons/icon-144x144.png"
  },
  {
    "revision": "749c0b64e206acfe1446c0435c2dbd49",
    "url": "images/icons/icon-152x152.png"
  },
  {
    "revision": "aa097738b33b9791260f9357915d3a3b",
    "url": "images/icons/icon-192x192.png"
  },
  {
    "revision": "ebb4766cb7be9148e119a51e16923525",
    "url": "images/icons/icon-384x384.png"
  },
  {
    "revision": "a799ce4691cc93d32e1c1b937f965c4e",
    "url": "images/icons/icon-512x512.png"
  },
  {
    "revision": "c21fee903cd1a7713e2319ce22b58c25",
    "url": "images/icons/icon-72x72.png"
  },
  {
    "revision": "77bf3363671eaa16124c57ec209b7790",
    "url": "images/icons/icon-96x96.png"
  },
  {
    "revision": "a377b0658e8b108bbe0ded775926dad0",
    "url": "index.html"
  },
  {
    "revision": "471434d6d44e18d38547",
    "url": "install.e67b6bc83ab7dfa42378.bundle.js"
  },
  {
    "revision": "e6747cf9527d065cfb12cefd0a98997d",
    "url": "manifest.json"
  },
  {
    "revision": "352e015efc537d5697ed",
    "url": "print.c55dde128c77c839a197.bundle.js"
  },
  {
    "revision": "3a64150859c06fd7ef2f04e3fca3216b",
    "url": "robots.txt"
  },
  {
    "revision": "83dafc96cfa5d406d5b4",
    "url": "runtime.005e6ecec332ab3a7f2b.bundle.js"
  },
  {
    "revision": "55db6f581ecba045d7ce3f833b800869",
    "url": "sw-offline-google-analytics.js"
  },
  {
    "revision": "7d06b090b2c83ace6728",
    "url": "vendor.96ed0a3a1de67d2e32cb.bundle.js"
  },
  {
    "revision": "2d7d3ae957e8afca53d7",
    "url": "vendors~app.0394bf9b626c19ab49f0.bundle.js"
  },
  {
    "revision": "d703e121d21379d4d974",
    "url": "vendors~app~vendor.76e25350db90270a2efc.bundle.js"
  },
  {
    "revision": "c307d458d54c9e1524984b0ae1f3e612",
    "url": "vendors~app~vendor.76e25350db90270a2efc.bundle.js.LICENSE"
  }
]);