self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "url": "./images/wechat-qr-code.c8d4fe131afb80931ca32f8f48e1501d.jpg"
  },
  {
    "revision": "dfec17b8f2ba8a59e892",
    "url": "1.99a28a2ed9a4218ddfe2.css"
  },
  {
    "revision": "45a380ebfadd4cc03f8e",
    "url": "10.9aad496a251b26d4c25b.bundle.js"
  },
  {
    "revision": "26777fe37a5dcadcfaaa",
    "url": "11.215ec45870f4aff9b491.bundle.js"
  },
  {
    "revision": "1e3d89408b58295e9c7d",
    "url": "12.3d400b84c04954fc13d1.bundle.js"
  },
  {
    "revision": "8072b47a8fb2c9c1d5b1",
    "url": "4.0b988d2aa67525a513c3.css"
  },
  {
    "revision": "d8f51b57c97b9434a2a9",
    "url": "5.dbf3fe2e6e9f19d099a1.bundle.js"
  },
  {
    "revision": "c307d458d54c9e1524984b0ae1f3e612",
    "url": "5.dbf3fe2e6e9f19d099a1.bundle.js.LICENSE"
  },
  {
    "revision": "39315d195c410ef9c764",
    "url": "6.0f5210445b4d4fa16072.bundle.js"
  },
  {
    "revision": "0d57d2af5a65e396ac3d61eab39b863c",
    "url": "6.0f5210445b4d4fa16072.bundle.js.LICENSE"
  },
  {
    "revision": "7a9af9e7569748b1f331",
    "url": "7.e14658f31f126ae5786e.bundle.js"
  },
  {
    "revision": "a508ad8662bb171b020e",
    "url": "8.4226c8d47af0bc88fbe9.bundle.js"
  },
  {
    "revision": "1ecc16b6d1691e162425",
    "url": "9.b5f00c4d0fc861b61fd6.bundle.js"
  },
  {
    "revision": "dfec17b8f2ba8a59e892",
    "url": "app.d0c4e9559ede8f7e58c7.bundle.js"
  },
  {
    "revision": "2351817742ecc337ea75f189d6e3a821",
    "url": "favicon.ico"
  },
  {
    "revision": "313cd83b50d857131d55d04f221ddd03",
    "url": "images/icons/icon-128x128.png"
  },
  {
    "revision": "5f380e168dd6c89f31a5ca0968661da1",
    "url": "images/icons/icon-144x144.png"
  },
  {
    "revision": "5a7efb209a32dca59ce7805805b526a1",
    "url": "images/icons/icon-152x152.png"
  },
  {
    "revision": "367759619dec2e13b6b235485004f487",
    "url": "images/icons/icon-192x192.png"
  },
  {
    "revision": "fc07c039cf77c092b5cecd0ecaf9b380",
    "url": "images/icons/icon-384x384.png"
  },
  {
    "revision": "548db322e8d457f71fc71763559dac0c",
    "url": "images/icons/icon-512x512.png"
  },
  {
    "revision": "74ec60f8550144e535a268c34ca4d89f",
    "url": "images/icons/icon-72x72.png"
  },
  {
    "revision": "3d4f59a7594f5ceda615bf2ad9afb499",
    "url": "images/icons/icon-96x96.png"
  },
  {
    "revision": "11bd89059f9591e28652ba09b63ffa82",
    "url": "index.html"
  },
  {
    "revision": "707543a71a890dcb88d9",
    "url": "install.85752c9134a72756cdf2.bundle.js"
  },
  {
    "revision": "e6747cf9527d065cfb12cefd0a98997d",
    "url": "manifest.json"
  },
  {
    "revision": "06fcf4d8105550ad0221",
    "url": "print.27261615460754eb18a3.bundle.js"
  },
  {
    "revision": "3a64150859c06fd7ef2f04e3fca3216b",
    "url": "robots.txt"
  },
  {
    "revision": "012db3e01038d7a4a17d",
    "url": "runtime.531ad8af262847859c52.bundle.js"
  },
  {
    "revision": "55db6f581ecba045d7ce3f833b800869",
    "url": "sw-offline-google-analytics.js"
  },
  {
    "revision": "8072b47a8fb2c9c1d5b1",
    "url": "vendors~app.2814fba0e390612702b3.bundle.js"
  }
]);