self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "url": "./img/wechat.86871ab10a9b22e9d837df84125dcd9e.jpg"
  },
  {
    "revision": "f49d5be165bd998ad135",
    "url": "app.css"
  },
  {
    "revision": "f49d5be165bd998ad135",
    "url": "app.f24dac24.bundle.js"
  },
  {
    "revision": "96e5bc7da1318a48a628abce95b2bfd5",
    "url": "index.html"
  },
  {
    "revision": "62b7b4f97e5bfd8fbebe",
    "url": "print.f24dac24.bundle.js"
  }
]);